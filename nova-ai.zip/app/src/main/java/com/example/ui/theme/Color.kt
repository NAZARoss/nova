package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Utility / Minimal Dark Palette (Matches Design HTML)
val BackgroundDark = Color(0xFF1C1B1F)
val OnBackgroundDark = Color(0xFFE6E1E5)
val SurfaceDark = Color(0xFF1C1B1F)
val OnSurfaceDark = Color(0xFFE6E1E5)
val SurfaceContainerDark = Color(0xFF2B2930)
val SurfaceVariantDark = Color(0xFF2B2930)
val OnSurfaceVariantDark = Color(0xFF938F99)
val OutlineDark = Color(0xFF49454F)

val PrimaryDark = Color(0xFFD0BCFF)
val OnPrimaryDark = Color(0xFF381E72)
val PrimaryContainerDark = Color(0xFF4F378B)
val OnPrimaryContainerDark = Color(0xFFEADDFF)

val SecondaryDark = Color(0xFFCCC2DC)
val OnSecondaryDark = Color(0xFF332D41)
val SecondaryContainerDark = Color(0xFF4A4458)
val OnSecondaryContainerDark = Color(0xFFE8DEF8)

val TertiaryDark = Color(0xFFEFB8C8)
val OnTertiaryDark = Color(0xFF492532)
val TertiaryContainerDark = Color(0xFF633B48)
val OnTertiaryContainerDark = Color(0xFFFFD8E4)

// Clean Utility / Minimal Light Palette
val BackgroundLight = Color(0xFFF7F5F9)
val OnBackgroundLight = Color(0xFF1C1B1F)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF1C1B1F)
val SurfaceContainerLight = Color(0xFFF3EDF7)
val SurfaceVariantLight = Color(0xFFE7E0EC)
val OnSurfaceVariantLight = Color(0xFF49454F)
val OutlineLight = Color(0xFF79747E)

val PrimaryLight = Color(0xFF6750A4)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFEADDFF)
val OnPrimaryContainerLight = Color(0xFF21005D)

val SecondaryLight = Color(0xFF625B71)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFE8DEF8)
val OnSecondaryContainerLight = Color(0xFF1D192B)

val TertiaryLight = Color(0xFF7D5260)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFFD8E4)
val OnTertiaryContainerLight = Color(0xFF31111D)

// Custom Accent & Status Colors (Clean Utility Minimal)
val StatusActiveGreen = Color(0xFFB2F0AD)
val StatusOnline = Color(0xFFB2F0AD)
val StatusWaiting = Color(0xFFFFD180)
val StatusPending = Color(0xFF938F99)
val StatusError = Color(0xFFF2B8B5)

val AiAccentGradientStart = Color(0xFFD0BCFF)
val AiAccentGradientEnd = Color(0xFF9A82DB)

val AvatarBackgroundDark = Color(0xFF49454F)
val BorderSubtleDark = Color(0x8049454F)
val BubbleUserDark = Color(0xFFD0BCFF)
val BubbleUserTextDark = Color(0xFF381E72)
val BubbleAiDark = Color(0xFF2B2930)
val BubbleAiTextDark = Color(0xFFE6E1E5)

